### Due Dates: 
	Due 9/29/22: 5 out of 11 elements used
	Due 9/30/22: 7 out of 11 elements used
	Day 10/04/22: Completed website with all the content
 
# Instructions  

  Create a basic website that includes all of the following elements:

	Lists
	Video
	Divs
	ID Attributes
	Line Breaks
	Images
	Multiple types of text elements
	Anchor elements (links)
	Target Attribute
	Comments
	Title element

Your website can be about anything you want! (As long as it's school appropriate). 
## Be Creative!